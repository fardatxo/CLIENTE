// appClases.js

class Poliza {
    constructor(gama, year, cobertura) {
      this._gama = gama;
      this._year = year;
      this._cobertura = cobertura;
      this._importe = 0;
    }
  
    // --- Getters y setters ---
    get gama() { return this._gama; }
    get year() { return this._year; }
    get cobertura() { return this._cobertura; }
    get importe() { return this._importe; }
  
    // --- Calcular seguro ---
    calcularSeguro() {
      const base = 300;
      let total = base;
  
      // Gama (en tu HTML los valores son "1", "2" y "3")
      switch (this._gama) {
        case "1":
          total += base * 0.05; // baja
          break;
        case "2":
          total += base * 0.15; // media
          break;
        case "3":
          total += base * 0.30; // alta
          break;
      }
  
      // Antigüedad del vehículo
      const actual = new Date().getFullYear();
      const antiguedad = actual - parseInt(this._year);
      total += total * (antiguedad * 0.03);
  
      // Tipo de cobertura
      if (this._cobertura.toLowerCase() === "básico") {
        total += total * 0.30;
      } else if (this._cobertura.toLowerCase() === "completo") {
        total += total * 0.50;
      }
  
      this._importe = Math.round(total);
      return this._importe;
    }
  
    // --- Mostrar información en el modal ---
    mostrarInfoHTML() {
      const total = this.calcularSeguro();
  
      // Asignar contenido al modal (según tu HTML)
      document.getElementById("staticBackdropLabel").textContent = "RESUMEN DE PÓLIZA";
  
      document.querySelector(".modal-body").innerHTML = `
        <p class="font-bold">Gama del vehículo: ${this._gama}</p>
        <p class="font-bold">Año del vehículo: ${this._year}</p>
        <p class="font-bold">Tipo de cobertura: ${this._cobertura}</p>
        <p class="font-bold">Importe total: ${total} €</p>
      `;
  
      document.querySelector(".modal-footer").innerHTML = `
        <button id="cerrarModal" class="btn btn-primary btn-raised col" type="button">Cerrar</button>
      `;
  
      // Mostrar modal con Bootstrap
      const modal = new bootstrap.Modal(document.getElementById("modal"));
      modal.show();
  
      // Cerrar modal al pulsar el botón
      document.getElementById("cerrarModal").addEventListener("click", () => {
        modal.hide();
      });
    }
  }
  
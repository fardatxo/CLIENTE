
/*------------------------------------------
-----------PROPIEDADES BÁSICAS --------------
--------------------------------------------*/

  //Tamaño pantalla
  console.log(screen.width); 
  console.log(screen.height);

  //Tamaño pantalla sin barra de tareas
  console.log(screen.availWidth); 
  console.log(screen.availHeight);

  //Profundidad de color de la pantalla
  console.log(screen.colorDepth); 

  

//  1. SELECCIÓN DE ELEMENTOS DEL HTML 
const formulario = document.querySelector('#formulario');        // El <form>
const enviar = document.querySelector('button[type="submit"]'); // Botón "Enviar"
const emailInput = document.querySelector('#email');            // Input de email
const asuntoInput = document.querySelector('#asunto');          // Input de asunto
const mensajeInput = document.querySelector('#mensaje');        // Textarea del mensaje

//  2. AMPLIACIÓN: AÑADIR CAMPO CC DINÁMICAMENTE (desde JS) 
const divCC = document.createElement('div');
divCC.className = 'flex flex-col space-y-2';
divCC.innerHTML = `
    <label for="cc" class="font-regular font-medium">CC:</label>
    <input id="cc" type="email" name="cc" placeholder="Destino copia, opcional" class="border border-gray-300 px-3 py-2 rounded-lg" />
`;
// Insertamos el bloque CC justo después del bloque de email
emailInput.closest('.flex').parentNode.insertBefore(divCC, emailInput.closest('.flex').nextElementSibling);
const ccInput = document.querySelector('#cc'); // Guardamos referencia al input de CC

//  3. ESTADO INICIAL DEL BOTÓN "ENVIAR" 
enviar.disabled = true;
enviar.classList.add('opacity-50', 'cursor-not-allowed');

//  4. EVENTOS 
// Validamos en tiempo real mientras el usuario escribe
formulario.addEventListener('input', validar);

// Escuchamos el evento 'reset' para limpiar errores cuando se pulse el botón Reset
formulario.addEventListener('reset', () => {
    // Limpiamos todos los mensajes de error
    document.querySelectorAll('.mensaje-error').forEach(el => el.remove());
    // Desactivamos el botón "Enviar" (estado inicial)
    enviar.disabled = true;
    enviar.classList.add('opacity-50', 'cursor-not-allowed');
});

// Manejamos el envío del formulario
formulario.addEventListener('submit', (e) => {
    e.preventDefault(); 

    // Validamos una última vez. Si falla no hacemos nada
    if (!validar()) return;

    //  5. CREAR Y MOSTRAR SPINNER  
    const spinner = document.createElement('div');
    spinner.id = 'spinner';
    spinner.className = 'flex justify-center mt-10';
    spinner.innerHTML = `
        <div class="sk-chase">
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
        </div>
    
        </style>
    `;
    formulario.after(spinner); // Lo insertamos justo después del formulario

    //  6. SIMULACIÓN DE ENVÍO (2 segundos) 
    setTimeout(() => {
        alert('El mensaje se ha enviado'); // Simulación permitida por el PDF

        //  7. MOSTRAR MENSAJE VERDE DE CONFIRMACIÓN (como en la imagen del PDF) 
        const mensajeVerde = document.createElement('div');
        mensajeVerde.id = 'mensaje-verde';
        mensajeVerde.className = 'bg-green-500 text-white p-2 text-center mt-5 rounded-lg';
        mensajeVerde.textContent = 'MENSAJE ENVIADO CORRECTAMENTE';
        formulario.after(mensajeVerde);

        //  8. SE VACIA
        setTimeout(() => {
            formulario.reset(); // Limpia todos los inputs
            // Borra todos los mensajes de error
            document.querySelectorAll('.mensaje-error').forEach(x => x.remove());
            // Desactiva el botón y lo pone gris
            enviar.disabled = true;
            enviar.classList.add('opacity-50', 'cursor-not-allowed');
            // Elimina el spinner y el mensaje verde
            spinner.remove();
            mensajeVerde.remove();
        }, 3000);

    }, 2000);
});

//  9. FUNCIÓN DE VALIDACIÓN (usa Object Literal, como pides) 
function validar() {
    // Regex exacta del PDF para validar emails
    const regex = /^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/;

    // OBJECT LITERAL: guardamos el estado de validación de cada campo
    const validaciones = {
        email: regex.test(emailInput.value.trim()),
        cc: ccInput.value.trim() === '' || regex.test(ccInput.value.trim()), //esto hace lo mismo que con el correo

        asunto: asuntoInput.value.trim() !== '',
        mensaje: mensajeInput.value.trim() !== ''
    };

    // Eliminamos todos los mensajes de error anteriores
    document.querySelectorAll('.mensaje-error').forEach(x => x.remove());

    // Mostramos errores solo si el campo es inválido
    if (!validaciones.email) mostrarError(emailInput, 'EMAIL');
    if (!validaciones.cc) mostrarError(ccInput, 'CC');
    if (!validaciones.asunto) mostrarError(asuntoInput, 'ASUNTO');
    if (!validaciones.mensaje) mostrarError(mensajeInput, 'MENSAJE');

    // Verificamos si todos los campos son válidos
    const todoValido = Object.values(validaciones).every(v => v === true);

    // Actualizamos el estado del botón
    if (todoValido) {
        enviar.disabled = false;
        enviar.classList.remove('opacity-50', 'cursor-not-allowed');
    } else {
        enviar.disabled = true;
        enviar.classList.add('opacity-50', 'cursor-not-allowed');
    }

    return todoValido;
}
//  10. FUNCIÓN PARA MOSTRAR MENSAJES DE ERROR 
function mostrarError(input, campo) {
    // Evitamos duplicar errores: si ya hay un mensaje justo después del input, no se creanmas
    if (input.nextElementSibling?.classList?.contains('mensaje-error')) {
        return;
    }
    // Creamos el mensaje de error con las clases
    const errorDiv = document.createElement('div');
    errorDiv.className = 'bg-red-600 text-white p-2 text-center mensaje-error';
    errorDiv.textContent = `El campo ${campo} es obligatorio y debe ser válido.`;
    // Lo insertamos justo debajo del input 
    input.parentNode.insertBefore(errorDiv, input.nextSibling);
}